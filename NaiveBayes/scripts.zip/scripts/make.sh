sudo apt-get install python-dev
sudo apt-get install python-pip
sudo pip install nltk