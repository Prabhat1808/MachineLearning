Please see the following [blog post](https://www.learnopencv.com/understanding-autoencoders-using-tensorflow-python/) for more details about this code

[Understanding Autoencoders using Tensorflow (Python)](https://www.learnopencv.com/understanding-autoencoders-using-tensorflow-python/)
