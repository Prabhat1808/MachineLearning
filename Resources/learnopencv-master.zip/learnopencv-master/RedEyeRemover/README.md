Please see the following [blog post](https://www.learnopencv.com/automatic-red-eye-remover-using-opencv-cpp-python/) for more details about this code

[Automatic Red Eye Remover using OpenCV (C++ / Python)](https://www.learnopencv.com/automatic-red-eye-remover-using-opencv-cpp-python/)
