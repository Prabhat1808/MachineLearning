Please see the following [blog post](https://www.learnopencv.com/filling-holes-in-an-image-using-opencv-python-c/) for more details about this code

[Filling holes in an image using OpenCV ( Python / C++ )](https://www.learnopencv.com/filling-holes-in-an-image-using-opencv-python-c/)
