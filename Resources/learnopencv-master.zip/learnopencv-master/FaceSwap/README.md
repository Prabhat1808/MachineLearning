Please see the following [blog post](https://www.learnopencv.com/face-swap-using-opencv-c-python/) for more details about this code

[Face Swap using OpenCV ( C++ / Python )](https://www.learnopencv.com/face-swap-using-opencv-c-python/)
