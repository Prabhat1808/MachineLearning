Please see the following [blog post](https://www.learnopencv.com/deep-learning-using-keras-the-basics) for more details about this code

[Deep learning using Keras – The Basics](https://www.learnopencv.com/deep-learning-using-keras-the-basics)
