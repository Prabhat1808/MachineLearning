Please see the following [blog post](https://www.learnopencv.com/image-classification-using-convolutional-neural-networks-in-keras) for more details about this code

[Image Classification using Convolutional Neural Networks in Keras( Python )](https://www.learnopencv.com/image-classification-using-convolutional-neural-networks-in-keras)
