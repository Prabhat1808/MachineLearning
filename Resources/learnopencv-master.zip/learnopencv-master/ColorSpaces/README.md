Please see the following [blog post](https://www.learnopencv.com/color-spaces-in-opencv-cpp-python/) for more details about this code

[Color spaces in OpenCV (C++ / Python)](https://www.learnopencv.com/color-spaces-in-opencv-cpp-python/)
