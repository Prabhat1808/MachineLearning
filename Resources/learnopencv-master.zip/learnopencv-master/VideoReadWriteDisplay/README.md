Please see the following [blog post](https://www.learnopencv.com/read-write-and-display-a-video-using-opencv-cpp-python/) for more details about this code

[Read, Write and Display a video using OpenCV ( C++/ Python )](https://www.learnopencv.com/read-write-and-display-a-video-using-opencv-cpp-python/)
