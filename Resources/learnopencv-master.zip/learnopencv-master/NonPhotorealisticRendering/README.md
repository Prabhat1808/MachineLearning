Please see the following [blog post](https://www.learnopencv.com/non-photorealistic-rendering-using-opencv-python-c/) for more details about this code

[Non-Photorealistic Rendering using OpenCV ( Python, C++ )](https://www.learnopencv.com/non-photorealistic-rendering-using-opencv-python-c/)
