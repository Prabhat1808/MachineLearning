Please see the following [blog post](https://www.learnopencv.com/how-to-find-frame-rate-or-frames-per-second-fps-in-opencv-python-cpp/) for more details about this code

[How to find frame rate or frames per second (fps) in OpenCV ( Python / C++ ) ?](https://www.learnopencv.com/how-to-find-frame-rate-or-frames-per-second-fps-in-opencv-python-cpp/)
