Please see the following [blog post](https://www.learnopencv.com/rotation-matrix-to-euler-angles/) for more details about this code

[Rotation Matrix To Euler Angles](https://www.learnopencv.com/rotation-matrix-to-euler-angles/)
