Please see the following [blog post](https://www.learnopencv.com/selective-search-for-object-detection-cpp-python/) for more details about this code

[Selective Search for Object Detection (C++ / Python)](https://www.learnopencv.com/selective-search-for-object-detection-cpp-python/)
