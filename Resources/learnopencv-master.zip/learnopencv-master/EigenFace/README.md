Please see the following [blog post](https://www.learnopencv.com/eigenface-using-opencv-c-python/) for more details about this code

[Eigenface using OpenCV (C++/Python)](https://www.learnopencv.com/eigenface-using-opencv-c-python/)
