Please see the following [blog post](https://www.learnopencv.com/opencv-threshold-python-cpp/) for more details about this code

[OpenCV Threshold ( Python , C++ )](https://www.learnopencv.com/opencv-threshold-python-cpp/)
