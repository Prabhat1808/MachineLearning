Details on how to use this code can be found in the link below. 

[How to Convert your OpenCV C++ code Into a Python Module](http://www.learnopencv.com/how-to-convert-your-opencv-c-code-into-a-python-module)
