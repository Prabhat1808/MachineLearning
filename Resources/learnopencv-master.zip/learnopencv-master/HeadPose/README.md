Please see the following [blog post](https://www.learnopencv.com/head-pose-estimation-using-opencv-and-dlib/) for more details about this code

[Head Pose Estimation using OpenCV and Dlib](https://www.learnopencv.com/head-pose-estimation-using-opencv-and-dlib/)
