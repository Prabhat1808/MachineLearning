Please see the following [blog post](https://www.learnopencv.com/computer-vision-for-predicting-facial-attractiveness/) for more details about this code

[Computer Vision for Predicting Facial Attractiveness](https://www.learnopencv.com/computer-vision-for-predicting-facial-attractiveness/)
