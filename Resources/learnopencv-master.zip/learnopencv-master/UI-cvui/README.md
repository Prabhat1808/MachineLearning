Please see the following [blog post](https://www.learnopencv.com/cvui-gui-lib-built-on-top-of-opencv-drawing-primitives/) for more details about this code

[cvui: A GUI lib built on top of OpenCV drawing primitives](https://www.learnopencv.com/cvui-gui-lib-built-on-top-of-opencv-drawing-primitives/)
